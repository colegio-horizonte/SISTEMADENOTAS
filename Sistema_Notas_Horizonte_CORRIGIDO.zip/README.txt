SISTEMA DE NOTAS — COLÉGIO HORIZONTE

ACESSO ADMINISTRATIVO
Usuário: joaopedroadmin
Senha: horizonteadmin

Atenção: abra o arquivo index.html no navegador mantendo o arquivo logo-colegio.png na mesma pasta.
O administrador cria os usuários dos professores e as matérias.

Esta é uma versão local (LocalStorage). Para uso real em rede, é necessário backend, banco de dados e autenticação segura.
